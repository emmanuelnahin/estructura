
import React, { useState } from 'react';
import { OrgNode } from '../types';
import { initialNodes } from '../constants';

export const UploadTab: React.FC<{ onImport: (nodes: OrgNode[]) => void }> = ({ onImport }) => {
  const [loading, setLoading] = useState(false);

  const loadSimulator = () => {
    setLoading(true);
    setTimeout(() => {
      onImport(initialNodes);
      setLoading(false);
    }, 1500);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setLoading(true);
    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const bstr = evt.target?.result;
        const workbook = (window as any).XLSX.read(bstr, { type: 'binary' });
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        const data = (window as any).XLSX.utils.sheet_to_json(sheet);
        
        const mapped: OrgNode[] = data.map((row: any) => ({
          id: String(row.id || row.ID || row.identificador || Math.random()),
          name: row.nombre || row.name || row.Nombre || 'Sin Nombre',
          title: row.cargo || row.title || row.Cargo || row.posicion || 'Colaborador',
          department: row.departamento || row.department || row.Departamento || row.area || 'General',
          parentId: row.jefe || row.parentId || row.Jefe || row.reporta_a || null,
          salary: row.salario || row.salary || row.sueldo || row.Salario ? Number(row.salario || row.salary || row.sueldo || row.Salario) : undefined,
          performance: row.desempeño || row.performance || row.rendimiento ? Number(row.desempeño || row.performance || row.rendimiento) : undefined,
          potential: (row.potencial || row.potential || 'Medio') as any,
          gender: (row.genero || row.gender || row.sexo || 'Otro') as any,
          isCritical: !!(row.critico || row.critical || row.es_critico),
          color: '#3b82f6'
        }));
        onImport(mapped);
      } catch (err) { 
        alert("Error procesando Excel. Asegúrate de que las columnas tengan nombres estándar."); 
      } finally { 
        setLoading(false); 
      }
    };
    reader.readAsBinaryString(file);
  };

  return (
    <div className="p-12 h-full flex flex-col items-center justify-center bg-slate-50">
      <div className="max-w-3xl w-full text-center space-y-12 animate-in fade-in zoom-in duration-700">
        <div className="w-24 h-24 bg-slate-900 text-white rounded-[2.5rem] flex items-center justify-center text-4xl mx-auto shadow-2xl">
          <i className="fas fa-brain"></i>
        </div>
        <div className="space-y-4">
          <h2 className="text-5xl font-black text-slate-900 tracking-tighter">Luxanalitica HR 360</h2>
          <p className="text-slate-500 text-lg max-w-xl mx-auto">
            Analiza <span className="text-blue-600 font-bold">Costos</span>, 
            <span className="text-emerald-600 font-bold"> Rendimiento</span> y 
            <span className="text-red-600 font-bold"> Sucesión</span> en tiempo real.
          </p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <button onClick={loadSimulator} className="group bg-white border-2 border-slate-100 p-8 rounded-[2.5rem] font-black text-slate-800 hover:border-blue-600 hover:bg-blue-50 transition-all shadow-xl flex flex-col items-center gap-3">
            <i className="fas fa-magic text-4xl text-blue-600 group-hover:scale-110 transition-transform"></i>
            <div>
              <p className="text-lg">Simular Estructura 360</p>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">Carga jerarquía compleja con KPIs vivos</p>
            </div>
          </button>
          <label className="group bg-slate-900 text-white p-8 rounded-[2.5rem] font-black hover:bg-slate-800 transition-all cursor-pointer shadow-xl flex flex-col items-center gap-3">
            <input type="file" accept=".xlsx,.xls" className="hidden" onChange={handleFileUpload} />
            <i className={`fas ${loading ? 'fa-sync fa-spin' : 'fa-file-excel'} text-4xl text-emerald-400`}></i>
            <div>
              <p className="text-lg">{loading ? 'Analizando...' : 'Subir Mi Estructura'}</p>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">Detecta salarios, rendimiento y potencial</p>
            </div>
          </label>
        </div>
      </div>
    </div>
  );
};
