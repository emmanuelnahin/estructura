
import React, { useState, useEffect } from 'react';
import { OrgNode } from '../types';
import { DEPARTMENTS, TITLES } from '../constants';

interface NodeFormProps {
  selectedNode: OrgNode | null;
  nodes: OrgNode[];
  onUpdate: (node: OrgNode) => void;
  onAdd: (node: OrgNode) => void;
  onDelete: (id: string) => void;
  onCancel: () => void;
}

export const NodeForm: React.FC<NodeFormProps> = ({ 
  selectedNode, 
  nodes, 
  onUpdate, 
  onAdd, 
  onDelete,
  onCancel
}) => {
  const [formData, setFormData] = useState<OrgNode>({
    id: '', name: '', title: '', department: '', parentId: null, color: '#3b82f6',
    isCritical: false, successionId: null, salary: 0, gender: 'Otro', seniority: 0,
    performance: 80, potential: 'Medio'
  });

  useEffect(() => {
    if (selectedNode) {
      setFormData({
        ...selectedNode,
        performance: selectedNode.performance ?? 80,
        potential: selectedNode.potential ?? 'Medio',
        salary: selectedNode.salary ?? 0,
        seniority: selectedNode.seniority ?? 0
      });
    } else {
      setFormData({ 
        id: `NEW-${Math.floor(1000 + Math.random() * 9000)}`, 
        name: '', title: '', department: DEPARTMENTS[0], parentId: null, color: '#3b82f6',
        isCritical: false, successionId: null, salary: 0, gender: 'Otro', seniority: 0,
        performance: 80, potential: 'Medio'
      });
    }
  }, [selectedNode]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    let val: any = value;
    if (type === 'checkbox') val = (e.target as HTMLInputElement).checked;
    if (type === 'number') val = value === '' ? 0 : Number(value);
    
    setFormData(prev => ({ ...prev, [name]: val === 'null' ? null : val }));
  };

  const handleSave = () => {
    if (!formData.name || !formData.title) {
      alert('Nombre y Cargo son obligatorios');
      return;
    }
    selectedNode ? onUpdate(formData) : onAdd(formData);
  };

  return (
    <div className="space-y-4 animate-in fade-in slide-in-from-left-4 duration-300">
      <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm space-y-4">
        {/* Información Básica */}
        <div className="space-y-3">
          <div>
            <label className="block text-[10px] font-black text-slate-400 uppercase mb-1 tracking-widest">Nombre Completo</label>
            <input name="name" value={formData.name} onChange={handleChange} className="w-full p-2.5 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500/20 outline-none" placeholder="Ej: Juan Perez" />
          </div>
          
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[10px] font-black text-slate-400 uppercase mb-1 tracking-widest">Cargo</label>
              <input name="title" value={formData.title} onChange={handleChange} className="w-full p-2.5 border border-slate-200 rounded-xl text-sm outline-none" placeholder="Ej: Director" />
            </div>
            <div>
              <label className="block text-[10px] font-black text-slate-400 uppercase mb-1 tracking-widest">Departamento</label>
              <select name="department" value={formData.department} onChange={handleChange} className="w-full p-2.5 border border-slate-200 rounded-xl text-xs bg-slate-50">
                {DEPARTMENTS.map(d => <option key={d} value={d}>{d}</option>)}
              </select>
            </div>
          </div>
        </div>

        {/* KPIs Talent 360 */}
        <div className="pt-4 border-t border-slate-100 grid grid-cols-2 gap-4">
          <div>
            <label className="block text-[10px] font-black text-slate-400 uppercase mb-1 tracking-widest">Rendimiento %</label>
            <div className="flex items-center gap-2">
              <input type="number" name="performance" value={formData.performance} onChange={handleChange} className="w-full p-2 border border-slate-200 rounded-xl text-sm" min="0" max="100" />
              <div className={`w-3 h-3 rounded-full ${formData.performance >= 85 ? 'bg-emerald-500' : (formData.performance >= 70 ? 'bg-amber-500' : 'bg-red-500')}`}></div>
            </div>
          </div>
          <div>
            <label className="block text-[10px] font-black text-slate-400 uppercase mb-1 tracking-widest">Potencial</label>
            <select name="potential" value={formData.potential} onChange={handleChange} className="w-full p-2 border border-slate-200 rounded-xl text-xs">
              <option value="Alto">Alto</option>
              <option value="Medio">Medio</option>
              <option value="Bajo">Bajo</option>
            </select>
          </div>
        </div>

        {/* Finanzas y Retención */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-[10px] font-black text-slate-400 uppercase mb-1 tracking-widest">Salario ($)</label>
            <input type="number" name="salary" value={formData.salary} onChange={handleChange} className="w-full p-2 border border-slate-200 rounded-xl text-sm" />
          </div>
          <div>
            <label className="block text-[10px] font-black text-slate-400 uppercase mb-1 tracking-widest">Antigüedad (Años)</label>
            <input type="number" name="seniority" value={formData.seniority} onChange={handleChange} className="w-full p-2 border border-slate-200 rounded-xl text-sm" />
          </div>
        </div>

        {/* Jerarquía: El Corazón del Flujo */}
        <div className="pt-4 border-t border-slate-100">
          <div className="p-3 bg-blue-50/50 rounded-2xl border border-blue-100">
            <label className="block text-[10px] font-black text-blue-600 uppercase mb-2 tracking-widest flex items-center gap-2">
              <i className="fas fa-sitemap"></i> Línea de Reporte
            </label>
            <select name="parentId" value={formData.parentId || 'null'} onChange={handleChange} className="w-full p-2.5 border border-blue-200 rounded-xl text-xs bg-white text-slate-700 shadow-sm focus:ring-2 focus:ring-blue-500/20">
              <option value="null">🔝 Dirección General / Sin Jefe</option>
              {nodes
                .filter(n => n.id !== formData.id) // No puede reportarse a sí mismo
                .sort((a, b) => a.name.localeCompare(b.name))
                .map(n => (
                  <option key={n.id} value={n.id}>{n.name} - {n.title}</option>
                ))}
            </select>
            <p className="text-[9px] text-blue-400 mt-2 font-medium italic">Cambiar el jefe moverá este colaborador y a todo su equipo en el organigrama.</p>
          </div>
        </div>

        {/* Riesgo Crítico */}
        <div className="flex items-center justify-between p-3 bg-red-50/50 rounded-2xl border border-red-100">
          <div className="flex items-center gap-2">
            <i className="fas fa-exclamation-circle text-red-500"></i>
            <span className="text-[10px] font-black text-red-700 uppercase">Posición Crítica</span>
          </div>
          <input type="checkbox" name="isCritical" checked={formData.isCritical} onChange={handleChange} className="w-5 h-5 rounded-lg text-red-600 focus:ring-red-500/20" />
        </div>
      </div>

      <div className="flex gap-2">
        {selectedNode && (
          <button onClick={() => onDelete(formData.id)} className="flex-1 bg-white border border-red-200 text-red-600 py-3 rounded-2xl font-black text-xs hover:bg-red-50 transition-all flex items-center justify-center gap-2">
            <i className="fas fa-trash-alt"></i> Eliminar
          </button>
        )}
        <button onClick={handleSave} className="flex-[2] bg-slate-900 text-white py-3 rounded-2xl font-black text-xs hover:bg-slate-800 transition-all shadow-xl flex items-center justify-center gap-2">
          <i className="fas fa-check-circle"></i> {selectedNode ? 'Guardar Cambios' : 'Crear Colaborador'}
        </button>
      </div>
      
      {!selectedNode && (
        <button onClick={onCancel} className="w-full py-2 text-slate-400 text-[10px] font-black uppercase tracking-widest hover:text-slate-600">
          Cancelar Creación
        </button>
      )}
    </div>
  );
};
