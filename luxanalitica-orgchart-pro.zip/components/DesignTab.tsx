
import React from 'react';
import { OrgNode } from '../types';
import { OrgChartD3 } from './OrgChartD3';
import { NodeForm } from './NodeForm';

interface DesignTabProps {
  nodes: OrgNode[];
  selectedNodeId: string | null;
  setSelectedNodeId: (id: string | null) => void;
  onUpdateNode: (node: OrgNode) => void;
  onAddNode: (node: OrgNode) => void;
  onDeleteNode: (id: string) => void;
}

export const DesignTab: React.FC<DesignTabProps> = ({ 
  nodes, 
  selectedNodeId, 
  setSelectedNodeId,
  onUpdateNode,
  onAddNode,
  onDeleteNode
}) => {
  const selectedNode = nodes.find(n => n.id === selectedNodeId) || null;

  return (
    <div className="flex h-full flex-col md:flex-row">
      {/* Editor Lateral */}
      <div className="w-full md:w-80 border-r border-slate-200 flex flex-col bg-slate-50 overflow-y-auto p-5 shrink-0">
        <div className="mb-6">
          <h3 className="font-bold text-slate-800 flex items-center gap-2 mb-1">
            <i className="fas fa-user-edit text-blue-600"></i>
            Propiedades del Nodo
          </h3>
          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Configuración de Flujo Jerárquico</p>
        </div>
        
        <NodeForm 
          selectedNode={selectedNode}
          nodes={nodes}
          onUpdate={onUpdateNode}
          onAdd={onAddNode}
          onDelete={onDeleteNode}
          onCancel={() => setSelectedNodeId(null)}
        />
      </div>

      {/* Área de Visualización */}
      <div className="flex-1 relative bg-slate-50 overflow-hidden">
        <div className="absolute top-4 right-4 z-10 flex flex-col gap-2">
            <div className="bg-white/90 backdrop-blur-sm border border-slate-200 rounded-xl p-3 shadow-lg flex flex-col gap-1 min-w-[150px]">
               <div className="flex justify-between items-center text-[10px] font-black text-slate-400 uppercase">
                  <span>Métricas</span>
                  <i className="fas fa-info-circle"></i>
               </div>
               <div className="flex flex-col text-sm font-bold text-slate-700">
                  <div className="flex justify-between"><span>Plantilla:</span> <span className="text-blue-600">{nodes.length}</span></div>
                  <div className="flex justify-between"><span>Niveles:</span> <span className="text-emerald-600">4</span></div>
               </div>
            </div>
        </div>
        
        <div className="w-full h-full">
           <OrgChartD3 
             nodes={nodes} 
             selectedNodeId={selectedNodeId} 
             onSelectNode={setSelectedNodeId} 
           />
        </div>

        <div className="absolute bottom-4 left-4 pointer-events-none">
           <div className="bg-slate-900/10 backdrop-blur-sm px-3 py-1.5 rounded-full border border-slate-900/5 flex items-center gap-2 text-[10px] font-bold text-slate-600">
              <i className="fas fa-mouse-pointer text-[8px]"></i>
              Haz clic en un nodo para editar su posición en el flujo
           </div>
        </div>
      </div>
    </div>
  );
};
