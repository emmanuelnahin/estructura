
import React from 'react';
import { OrgNode } from '../types';

export const ExportTab: React.FC<{ nodes: OrgNode[] }> = ({ nodes }) => {
  const handleExport = () => {
    const ws = (window as any).XLSX.utils.json_to_sheet(nodes);
    const wb = (window as any).XLSX.utils.book_new();
    (window as any).XLSX.utils.book_append_sheet(wb, ws, "OrgChart");
    (window as any).XLSX.writeFile(wb, `Luxanalitica_Export_${new Date().toISOString().slice(0,10)}.xlsx`);
  };

  return (
    <div className="p-12 h-full bg-slate-50 flex flex-col items-center justify-center">
      <div className="max-w-4xl w-full grid grid-cols-1 md:grid-cols-2 gap-8">
        <ExportItem 
          icon="fa-file-excel" 
          title="Base de Datos (Excel)" 
          desc="Descarga la estructura completa en formato compatible con Excel para auditorías o cargas masivas." 
          onAction={handleExport}
          btnColor="bg-emerald-600"
          btnText="Descargar Excel"
        />
        <ExportItem 
          icon="fa-file-image" 
          title="Captura de Pantalla" 
          desc="Próximamente: Genera una imagen PNG de alta resolución de tu organigrama actual." 
          onAction={() => alert('Función en desarrollo')}
          btnColor="bg-slate-400"
          btnText="Guardar Imagen"
          disabled={true}
        />
      </div>
    </div>
  );
};

const ExportItem = ({ icon, title, desc, onAction, btnColor, btnText, disabled }: any) => (
  <div className="bg-white p-10 rounded-3xl border border-slate-200 shadow-xl flex flex-col items-center text-center space-y-6 transform hover:scale-[1.02] transition-transform">
    <div className="text-5xl text-slate-200">
      <i className={`fas ${icon}`}></i>
    </div>
    <div className="space-y-2">
      <h3 className="text-2xl font-black text-slate-800 tracking-tight">{title}</h3>
      <p className="text-slate-500 text-sm leading-relaxed px-4">{desc}</p>
    </div>
    <button 
      onClick={onAction}
      disabled={disabled}
      className={`w-full py-4 ${btnColor} text-white rounded-2xl font-black shadow-lg shadow-black/10 transition-all hover:brightness-110 disabled:cursor-not-allowed`}
    >
      {btnText}
    </button>
  </div>
);
