
import React, { useRef, useEffect } from 'react';
import { OrgNode } from '../types';
import * as d3 from 'd3';

interface OrgChartProps {
  nodes: OrgNode[];
  selectedNodeId: string | null;
  onSelectNode: (id: string | null) => void;
}

export const OrgChartD3: React.FC<OrgChartProps> = ({ nodes, selectedNodeId, onSelectNode }) => {
  const svgRef = useRef<SVGSVGElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!svgRef.current || !containerRef.current || nodes.length === 0) return;

    const width = containerRef.current.clientWidth, height = containerRef.current.clientHeight;
    const svg = d3.select(svgRef.current).attr('width', width).attr('height', height);
    svg.selectAll('*').remove();

    const defs = svg.append('defs');
    const shadow = defs.append('filter').attr('id', 'premium-shadow').attr('height', '130%');
    shadow.append('feGaussianBlur').attr('in', 'SourceAlpha').attr('stdDeviation', 3);
    shadow.append('feOffset').attr('dx', 0).attr('dy', 4).attr('result', 'offsetBlur');
    const feMerge = shadow.append('feMerge');
    feMerge.append('feMergeNode').attr('in', 'offsetBlur');
    feMerge.append('feMergeNode').attr('in', 'SourceGraphic');

    const g = svg.append('g');
    const zoom = d3.zoom<SVGSVGElement, unknown>().scaleExtent([0.1, 3]).on('zoom', (e) => g.attr('transform', e.transform));
    svg.call(zoom);

    try {
      const nodeMap = new Map<string, OrgNode>(nodes.map(n => [n.id, n]));
      const processed = nodes.map(n => ({...n}));
      const roots = processed.filter(n => !n.parentId || !nodeMap.has(n.parentId));
      const vRootId = 'VMASTER';
      processed.push({ id: vRootId, name: '', title: '', department: '', parentId: null });
      roots.forEach(r => r.parentId = vRootId);

      const root = d3.stratify<OrgNode>().id(d => d.id).parentId(d => d.parentId)(processed);
      d3.tree<OrgNode>().nodeSize([240, 240])(root);

      // Dibujar enlaces curvos suaves
      g.selectAll('.link').data(root.links()).enter().append('path').filter((d: any) => d.source.id !== vRootId)
        .attr('fill', 'none').attr('stroke', '#cbd5e1').attr('stroke-width', 2).attr('opacity', 0.6)
        .attr('d', d3.linkVertical().x((d: any) => d.x).y((d: any) => d.y) as any);

      const node = g.selectAll('.node').data(root.descendants()).enter().append('g')
        .filter((d: any) => d.id !== vRootId)
        .attr('transform', (d: any) => `translate(${d.x},${d.y})`)
        .on('click', (e, d) => { e.stopPropagation(); onSelectNode(d.id || null); })
        .style('cursor', 'pointer');

      // Card
      node.append('rect').attr('width', 200).attr('height', 110).attr('x', -100).attr('y', -55).attr('rx', 24)
        .attr('fill', 'white').attr('filter', 'url(#premium-shadow)')
        .attr('stroke', (d: any) => {
          if (d.id === selectedNodeId) return '#2563eb';
          if (d.data.isCritical && !d.data.successionId) return '#ef4444';
          return '#f1f5f9';
        })
        .attr('stroke-width', (d: any) => d.id === selectedNodeId || (d.data.isCritical && !d.data.successionId) ? 3 : 1)
        .attr('class', (d: any) => d.data.isCritical && !d.data.successionId ? 'animate-pulse' : '');

      // Barra superior departamento
      node.append('rect').attr('width', 200).attr('height', 10).attr('x', -100).attr('y', -55).attr('rx', 5)
        .attr('fill', (d: any) => d.data.color || '#3b82f6');

      // Nombre
      node.append('text').attr('dy', -20).attr('x', -85).attr('class', 'text-[12px] font-black fill-slate-900')
        .text(d => d.data.name.length > 22 ? d.data.name.slice(0, 20) + '..' : d.data.name);

      // Cargo
      node.append('text').attr('dy', -5).attr('x', -85).attr('class', 'text-[10px] fill-slate-500 font-bold')
        .text(d => d.data.title);

      // Dept
      node.append('text').attr('dy', 10).attr('x', -85).attr('class', 'text-[9px] font-black uppercase tracking-widest fill-blue-600/70')
        .text(d => d.data.department);

      // Barra de Desempeño Viva
      const pG = node.append('g').attr('transform', 'translate(-85, 25)');
      pG.append('rect').attr('width', 130).attr('height', 4).attr('fill', '#f1f5f9').attr('rx', 2);
      pG.append('rect').attr('width', (d: any) => (d.data.performance || 0) * 1.3).attr('height', 4).attr('rx', 2)
        .attr('fill', (d: any) => (d.data.performance || 0) > 85 ? '#10b981' : ((d.data.performance || 0) > 70 ? '#f59e0b' : '#ef4444'));

      // Badge Potencial
      const badge = node.append('g').attr('transform', 'translate(50, 25)');
      badge.append('rect').attr('width', 35).attr('height', 16).attr('rx', 8)
        .attr('fill', (d: any) => d.data.potential === 'Alto' ? '#dcfce7' : (d.data.potential === 'Medio' ? '#fef3c7' : '#f1f5f9'));
      badge.append('text').attr('x', 17.5).attr('y', 11).attr('text-anchor', 'middle').attr('class', 'text-[8px] font-black uppercase')
        .attr('fill', (d: any) => d.data.potential === 'Alto' ? '#166534' : (d.data.potential === 'Medio' ? '#92400e' : '#64748b'))
        .text(d => d.data.potential === 'Alto' ? 'Top' : (d.data.potential === 'Medio' ? 'Pot' : 'Low'));

      svg.transition().duration(800).call(zoom.transform, d3.zoomIdentity.translate(width / 2, 80).scale(0.8));
    } catch (err) { console.error(err); }
  }, [nodes, selectedNodeId]);

  return (
    <div id="capture-area" ref={containerRef} className="w-full h-full bg-slate-50 relative overflow-hidden">
      <svg ref={svgRef} className="w-full h-full outline-none" onClick={() => onSelectNode(null)} />
    </div>
  );
};
