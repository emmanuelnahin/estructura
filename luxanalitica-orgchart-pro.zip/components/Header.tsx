
import React, { useState, useEffect } from 'react';

export const Header: React.FC = () => {
  const [time, setTime] = useState(new Date().toLocaleTimeString());

  useEffect(() => {
    const t = setInterval(() => setTime(new Date().toLocaleTimeString()), 1000);
    return () => clearInterval(t);
  }, []);

  return (
    <header className="bg-white border-b border-slate-200 px-8 py-4 flex justify-between items-center z-10">
      <div className="flex items-center gap-4">
        <div className="p-2 bg-blue-50 rounded-lg">
          <i className="fas fa-project-diagram text-blue-600 text-xl"></i>
        </div>
        <div>
          <h1 className="text-xl font-bold text-slate-800">Estructura Organizacional</h1>
          <p className="text-xs text-slate-400 font-semibold tracking-wide uppercase">Módulo de Diseño de Flujo</p>
        </div>
      </div>
      
      <div className="hidden md:flex items-center gap-6">
        <div className="text-right">
          <div className="text-sm font-bold text-slate-700">{new Date().toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric', month: 'long' })}</div>
          <div className="text-xs text-slate-400 font-mono">{time}</div>
        </div>
        <div className="h-10 w-[1px] bg-slate-200"></div>
        <div className="flex items-center gap-3">
          <div className="text-right">
            <div className="text-xs font-bold text-slate-800">Admin User</div>
            <div className="text-[10px] text-emerald-500 font-bold uppercase">Online</div>
          </div>
          <div className="w-10 h-10 rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-400">
            <i className="fas fa-user-circle text-2xl"></i>
          </div>
        </div>
      </div>
    </header>
  );
};
