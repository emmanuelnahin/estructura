
import React, { useMemo } from 'react';
import { OrgNode } from '../types';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  Cell, PieChart, Pie, Legend, ComposedChart, Line, ScatterChart, Scatter, ZAxis,
  AreaChart, Area
} from 'recharts';

export const AnalysisTab: React.FC<{ nodes: OrgNode[] }> = ({ nodes }) => {
  const stats = useMemo(() => {
    if (!nodes || nodes.length === 0) return null;

    const nodeMap = new Map(nodes.map(n => [n.id, n]));
    
    // Filtros inteligentes para ignorar datos incompletos
    const validSalaries = nodes.filter(n => typeof n.salary === 'number' && n.salary > 0);
    const validPerformances = nodes.filter(n => typeof n.performance === 'number');
    const validSeniority = nodes.filter(n => typeof n.seniority === 'number');

    const totalSalary = validSalaries.reduce((sum, n) => sum + (n.salary || 0), 0);
    const avgPerf = validPerformances.length > 0 
      ? Math.round(validPerformances.reduce((sum, n) => sum + (n.performance || 0), 0) / validPerformances.length)
      : 0;

    // Estadísticas por Departamento
    const deptStats = Array.from(new Set(nodes.map(n => n.department))).map(dept => {
      const deptNodes = nodes.filter(n => n.department === dept);
      const deptSalaries = deptNodes.filter(n => typeof n.salary === 'number' && n.salary > 0);
      const deptPerfs = deptNodes.filter(n => typeof n.performance === 'number');
      const deptSeniority = deptNodes.filter(n => typeof n.seniority === 'number');
      
      return {
        name: dept,
        count: deptNodes.length,
        avgSalary: deptSalaries.length > 0 ? Math.round(deptSalaries.reduce((s, n) => s + (n.salary || 0), 0) / deptSalaries.length) : 0,
        avgPerf: deptPerfs.length > 0 ? Math.round(deptPerfs.reduce((s, n) => s + (n.performance || 0), 0) / deptPerfs.length) : 0,
        avgSeniority: deptSeniority.length > 0 ? Number((deptSeniority.reduce((s, n) => s + (n.seniority || 0), 0) / deptSeniority.length).toFixed(1)) : 0
      };
    }).sort((a, b) => b.count - a.count);

    const criticalIssues = nodes.filter(n => n.isCritical && (!n.successionId || !nodeMap.has(n.successionId)));
    const riskLevel = nodes.filter(n => n.isCritical).length > 0 
      ? Math.round((criticalIssues.length / nodes.filter(n => n.isCritical).length) * 100) 
      : 0;

    // 9-Box Matrix Data
    const matrixData = validPerformances.map(n => ({
      name: n.name,
      perf: n.performance,
      pot: n.potential === 'Alto' ? 3 : (n.potential === 'Medio' ? 2 : 1),
      potLabel: n.potential,
      salary: n.salary
    }));

    // Género
    const genderCount = nodes.reduce((acc: any, n) => {
      if (n.gender) acc[n.gender] = (acc[n.gender] || 0) + 1;
      return acc;
    }, {});

    // Top Talents (9-Box: Potencial Alto y Desempeño > 85)
    const topTalents = nodes.filter(n => n.potential === 'Alto' && (n.performance || 0) >= 85);

    return {
      totalSalary,
      avgPerf,
      deptStats,
      matrixData,
      riskLevel,
      criticalCount: criticalIssues.length,
      genderData: Object.entries(genderCount).map(([name, value]) => ({ name, value })),
      poblacion: nodes.length,
      topTalents
    };
  }, [nodes]);

  if (!stats) return (
    <div className="h-full flex flex-col items-center justify-center text-slate-400 gap-4">
      <i className="fas fa-chart-pie text-7xl opacity-10"></i>
      <p className="font-bold text-xl">Dashboard 360° esperando datos...</p>
      <p className="text-sm opacity-60">Sube un Excel o usa el Simulador en la pestaña "Cargar Excel"</p>
    </div>
  );

  const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#06b6d4'];

  return (
    <div className="p-6 h-full overflow-y-auto bg-slate-50/50 space-y-6 scrollbar-hide animate-in fade-in duration-700">
      {/* SECCIÓN 1: KPIs ESTRATÉGICOS */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <KPIBox icon="fa-users" color="blue" label="Plantilla Total" value={stats.poblacion} sub="Colaboradores activos" />
        <KPIBox icon="fa-rocket" color="emerald" label="Productividad Global" value={`${stats.avgPerf}%`} sub="Promedio rendimiento" />
        <KPIBox icon="fa-funnel-dollar" color="indigo" label="Presupuesto Mensual" value={`$${(stats.totalSalary / 1000).toFixed(1)}k`} sub="Masa salarial bruta" />
        <KPIBox icon="fa-shield-alt" color="red" label="Continuidad Crítica" value={`${stats.riskLevel}%`} sub="Riesgo de sucesión" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* SECCIÓN 2: MATRIZ DE TALENTO 9-BOX */}
        <div className="bg-white p-6 rounded-[2.5rem] border border-slate-200 shadow-sm flex flex-col min-h-[400px]">
          <div className="flex justify-between items-center mb-6">
            <h4 className="font-black text-slate-800 flex items-center gap-3">
              <i className="fas fa-th-large text-blue-500"></i> Matriz de Talento 9-Box
            </h4>
            <span className="text-[10px] bg-blue-100 text-blue-700 px-2 py-1 rounded-full font-black">ESTRATÉGICO</span>
          </div>
          <div className="flex-1">
            <ResponsiveContainer width="100%" height="100%">
              <ScatterChart margin={{ top: 10, right: 30, bottom: 30, left: 10 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis type="number" dataKey="perf" name="Desempeño" domain={[0, 100]} unit="%" fontSize={10} tick={{fill: '#94a3b8'}} label={{ value: 'Desempeño Operativo', position: 'bottom', fontSize: 10, fill: '#64748b', dy: 10 }} />
                <YAxis type="number" dataKey="pot" name="Potencial" domain={[0, 4]} ticks={[1, 2, 3]} tickFormatter={(v) => v === 3 ? 'Alto' : (v === 2 ? 'Med' : 'Bajo')} fontSize={10} tick={{fill: '#94a3b8'}} />
                <ZAxis type="number" dataKey="salary" range={[100, 800]} />
                <Tooltip cursor={{ strokeDasharray: '3 3' }} content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const d = payload[0].payload;
                    return (
                      <div className="bg-slate-900 text-white p-3 rounded-2xl text-[10px] shadow-2xl border border-slate-700">
                        <p className="font-black mb-1 text-blue-400 border-b border-slate-800 pb-1">{d.name}</p>
                        <p>Desempeño: <span className="text-emerald-400">{d.perf}%</span></p>
                        <p>Potencial: <span className="text-amber-400">{d.potLabel}</span></p>
                      </div>
                    );
                  }
                  return null;
                }} />
                <Scatter data={stats.matrixData} fill="#3b82f6" fillOpacity={0.6} stroke="#2563eb" strokeWidth={1} />
              </ScatterChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* SECCIÓN 3: EFICIENCIA POR ÁREA */}
        <div className="bg-white p-6 rounded-[2.5rem] border border-slate-200 shadow-sm flex flex-col min-h-[400px]">
          <h4 className="font-black text-slate-800 mb-6 flex items-center gap-3">
            <i className="fas fa-chart-line text-emerald-500"></i> Eficiencia: Costo vs Desempeño
          </h4>
          <div className="flex-1">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={stats.deptStats}>
                <XAxis dataKey="name" fontSize={9} tick={{fill: '#94a3b8'}} axisLine={false} tickLine={false} />
                <YAxis yAxisId="left" hide />
                <YAxis yAxisId="right" orientation="right" hide />
                <Tooltip />
                <Bar yAxisId="left" dataKey="avgSalary" fill="#3b82f6" radius={[8, 8, 0, 0]} barSize={30} name="Salario Medio" />
                <Line yAxisId="right" type="monotone" dataKey="avgPerf" stroke="#10b981" strokeWidth={3} dot={{ r: 4, fill: '#10b981' }} name="Rendimiento %" />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-4 flex justify-center gap-6 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
            <span className="flex items-center gap-2"><div className="w-2 h-2 bg-blue-500 rounded-full"></div> Inversión Salarial</span>
            <span className="flex items-center gap-2"><div className="w-2 h-2 bg-emerald-500 rounded-full"></div> Rendimiento Operativo</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 pb-10">
        {/* SECCIÓN 4: ANTIGÜEDAD Y EXPERIENCIA */}
        <div className="bg-white p-6 rounded-[2.5rem] border border-slate-200 shadow-sm flex flex-col h-[350px]">
          <h4 className="font-black text-slate-800 mb-6 flex items-center gap-3">
            <i className="fas fa-hourglass-half text-amber-500"></i> Seniority (Años de Exp)
          </h4>
          <div className="flex-1">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.deptStats} layout="vertical">
                <XAxis type="number" hide />
                <YAxis dataKey="name" type="category" width={80} fontSize={8} tick={{fill: '#64748b'}} axisLine={false} />
                <Tooltip />
                <Bar dataKey="avgSeniority" fill="#f59e0b" radius={[0, 8, 8, 0]} name="Años Promedio" barSize={15} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* SECCIÓN 5: DIVERSIDAD Y TOP TALENTS */}
        <div className="bg-white p-6 rounded-[2.5rem] border border-slate-200 shadow-sm h-[350px]">
          <h4 className="font-black text-slate-800 mb-2">Composición del Equipo</h4>
          <div className="h-44">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={stats.genderData} innerRadius={50} outerRadius={70} dataKey="value" stroke="none" paddingAngle={8}>
                  {stats.genderData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip />
                <Legend iconType="circle" />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-4 pt-4 border-t border-slate-50 flex items-center justify-between">
             <div className="text-center">
                <p className="text-[10px] font-black text-slate-400 uppercase">Top Performers</p>
                <p className="text-xl font-black text-emerald-600">{stats.topTalents.length}</p>
             </div>
             <div className="h-8 w-[1px] bg-slate-100"></div>
             <div className="text-center">
                <p className="text-[10px] font-black text-slate-400 uppercase">Promedio Dept</p>
                <p className="text-xl font-black text-slate-800">{Math.round(stats.poblacion / stats.deptStats.length)}</p>
             </div>
          </div>
        </div>

        {/* SECCIÓN 6: ALERTAS DE RIESGO */}
        <div className="bg-slate-900 p-8 rounded-[2.5rem] shadow-2xl flex flex-col justify-center text-white relative overflow-hidden">
           <div className="absolute -top-10 -right-10 w-40 h-40 bg-blue-600/20 rounded-full blur-3xl"></div>
           <div className="relative z-10">
              <div className="flex items-center gap-4 mb-6">
                <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-2xl shadow-lg ${stats.riskLevel > 25 ? 'bg-red-500' : 'bg-emerald-500'}`}>
                  <i className={`fas ${stats.riskLevel > 25 ? 'fa-exclamation-triangle' : 'fa-shield-check'}`}></i>
                </div>
                <div>
                  <h4 className="font-black text-lg">Estado de Salud HR</h4>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Análisis de Continuidad</p>
                </div>
              </div>

              <div className="space-y-4">
                <RiskMiniItem label="Cargos Críticos sin Sucesor" value={stats.criticalCount} total={nodes.filter(n => n.isCritical).length} color="red" />
                <RiskMiniItem label="Colaboradores High-Performance" value={stats.topTalents.length} total={nodes.length} color="emerald" />
                <RiskMiniItem label="Índice de Retención Proyectado" value={100 - stats.riskLevel} total={100} color="blue" />
              </div>

              <button className="w-full mt-8 py-3 bg-white/10 hover:bg-white/20 border border-white/20 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all">
                Generar Reporte Ejecutivo PDF
              </button>
           </div>
        </div>
      </div>
    </div>
  );
};

const KPIBox = ({ icon, color, label, value, sub }: any) => {
  const colorMap: any = { blue: 'bg-blue-600', emerald: 'bg-emerald-600', indigo: 'bg-indigo-600', red: 'bg-red-600' };
  return (
    <div className="bg-white p-6 rounded-[2.2rem] border border-slate-200 shadow-sm flex items-center gap-5 group hover:border-slate-300 transition-all">
      <div className={`w-14 h-14 rounded-2xl ${colorMap[color]} flex items-center justify-center text-white text-xl shadow-lg group-hover:scale-110 transition-transform`}>
        <i className={`fas ${icon}`}></i>
      </div>
      <div>
        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest leading-none mb-1">{label}</p>
        <p className="text-2xl font-black text-slate-900 leading-tight">{value}</p>
        <p className="text-[9px] font-medium text-slate-500 mt-0.5">{sub}</p>
      </div>
    </div>
  );
};

const RiskMiniItem = ({ label, value, total, color }: any) => {
  const percentage = total > 0 ? (value / total) * 100 : 0;
  const barColors: any = { red: 'bg-red-500', emerald: 'bg-emerald-500', blue: 'bg-blue-500' };
  return (
    <div className="space-y-1">
       <div className="flex justify-between text-[10px] font-black uppercase tracking-tight">
          <span className="text-slate-400">{label}</span>
          <span className="text-white">{value} / {total}</span>
       </div>
       <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
          <div className={`h-full ${barColors[color]} transition-all duration-1000`} style={{ width: `${percentage}%` }}></div>
       </div>
    </div>
  );
};
