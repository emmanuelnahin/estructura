
import React, { useState } from 'react';
import { OrgNode, ViewMode } from '../types';
import { OrgChartD3 } from './OrgChartD3';

export const VisualTab: React.FC<{ 
  nodes: OrgNode[], 
  viewMode: ViewMode, 
  setViewMode: (v: ViewMode) => void 
}> = ({ nodes, viewMode, setViewMode }) => {
  const [isExporting, setIsExporting] = useState(false);

  const handleExportPDF = async () => {
    setIsExporting(true);
    const element = document.getElementById('capture-area');
    if (!element) return;
    
    try {
      const canvas = await (window as any).html2canvas(element, { scale: 2 });
      const imgData = canvas.toDataURL('image/png');
      const pdf = new (window as any).jspdf.jsPDF('l', 'px', [canvas.width, canvas.height]);
      pdf.addImage(imgData, 'PNG', 0, 0, canvas.width, canvas.height);
      pdf.save(`Luxanalitica_OrgChart_${new Date().toISOString().split('T')[0]}.pdf`);
    } catch (err) {
      console.error("Export Error:", err);
    } finally {
      setIsExporting(false);
    }
  };

  const handleExportImage = async () => {
    setIsExporting(true);
    const element = document.getElementById('capture-area');
    if (!element) return;
    
    try {
      const canvas = await (window as any).html2canvas(element, { scale: 3 });
      const link = document.createElement('a');
      link.download = `Luxanalitica_Chart_${Date.now()}.jpg`;
      link.href = canvas.toDataURL('image/jpeg', 0.9);
      link.click();
    } catch (err) {
      console.error("Image Export Error:", err);
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-50">
      <div className="p-4 bg-white border-b border-slate-200 flex justify-between items-center shadow-sm z-10">
        <div className="flex items-center gap-4">
          <div className="px-3 py-1 bg-slate-100 rounded-lg flex items-center gap-2">
             <i className="fas fa-sitemap text-blue-600"></i>
             <span className="text-[10px] font-black text-slate-800 uppercase tracking-widest">Vista Jerárquica Elite</span>
          </div>
        </div>
        
        <div className="flex gap-2">
           <button 
             onClick={handleExportImage}
             disabled={isExporting}
             className="px-4 py-2 bg-slate-800 text-white rounded-xl text-xs font-bold hover:bg-slate-700 transition-all flex items-center gap-2 disabled:opacity-50"
           >
              {isExporting ? <i className="fas fa-spinner fa-spin"></i> : <i className="fas fa-file-image"></i>}
              Exportar JPG
           </button>
           <button 
             onClick={handleExportPDF}
             disabled={isExporting}
             className="px-4 py-2 bg-blue-600 text-white rounded-xl text-xs font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-500/20 flex items-center gap-2 disabled:opacity-50"
           >
              {isExporting ? <i className="fas fa-spinner fa-spin"></i> : <i className="fas fa-file-pdf"></i>}
              Descargar PDF Completo
           </button>
        </div>
      </div>
      
      <div className="flex-1 relative overflow-hidden">
         <OrgChartD3 
           nodes={nodes} 
           selectedNodeId={null} 
           onSelectNode={() => {}} 
         />
         
         <div className="absolute top-4 left-4 bg-white/80 backdrop-blur-md p-3 rounded-2xl border border-slate-200 shadow-xl pointer-events-none">
            <h5 className="text-[9px] font-black text-slate-400 uppercase mb-2">Leyenda de Estructura</h5>
            <div className="space-y-1.5">
               <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-500"></div>
                  <span className="text-[10px] font-bold text-slate-600">Posición Estable</span>
               </div>
               <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-amber-500"></div>
                  <span className="text-[10px] font-bold text-slate-600">Crítico con Plan</span>
               </div>
               <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse"></div>
                  <span className="text-[10px] font-bold text-slate-600">Riesgo de Continuidad</span>
               </div>
            </div>
         </div>
      </div>
    </div>
  );
};
