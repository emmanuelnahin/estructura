
import React from 'react';

interface TabProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const TabNavigation: React.FC<TabProps> = ({ activeTab, setActiveTab }) => {
  const tabs = [
    { id: 'carga', label: 'Cargar Excel', icon: 'fa-cloud-upload-alt' },
    { id: 'diseno', label: 'Editor de Flujo', icon: 'fa-pencil-ruler' },
    { id: 'visualizacion', label: 'Vista Expandida', icon: 'fa-expand' },
    { id: 'analisis', label: 'HR Analytics', icon: 'fa-chart-pie' },
    { id: 'exportacion', label: 'Exportar', icon: 'fa-file-download' },
  ];

  return (
    <div className="flex bg-white rounded-t-2xl border-t border-x border-slate-200 overflow-x-auto scrollbar-hide shrink-0">
      {tabs.map((tab) => (
        <button
          key={tab.id}
          onClick={() => setActiveTab(tab.id)}
          className={`flex-1 min-w-[140px] py-4 px-6 flex items-center justify-center gap-3 transition-all duration-300 border-b-4 ${
            activeTab === tab.id 
              ? 'bg-blue-50/50 border-blue-600 text-blue-700 font-bold' 
              : 'border-transparent text-slate-400 hover:text-slate-600 hover:bg-slate-50'
          }`}
        >
          <i className={`fas ${tab.icon} text-lg`}></i>
          <span className="text-sm whitespace-nowrap">{tab.label}</span>
        </button>
      ))}
    </div>
  );
};
