
import React from 'react';

interface SidebarProps {
  isOpen: boolean;
  onToggle: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ isOpen, onToggle }) => {
  return (
    <div className={`${isOpen ? 'w-64' : 'w-20'} h-full bg-slate-900 text-white transition-all duration-300 flex flex-col shrink-0 z-20 shadow-2xl`}>
      <div className="p-6 flex items-center gap-4 overflow-hidden whitespace-nowrap border-b border-slate-800">
        <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center shrink-0 shadow-lg">
          <i className="fas fa-layer-group text-lg"></i>
        </div>
        {isOpen && <span className="font-bold text-xl tracking-tight">Luxanalitica</span>}
      </div>

      <nav className="flex-1 mt-6 px-3 space-y-2">
        <NavItem icon="fa-sitemap" label="Organigrama" active={true} isOpen={isOpen} />
        <NavItem icon="fa-users" label="Plantilla" active={false} isOpen={isOpen} />
        <NavItem icon="fa-chart-line" label="KPIs HR" active={false} isOpen={isOpen} />
        <NavItem icon="fa-cog" label="Configuración" active={false} isOpen={isOpen} />
      </nav>

      <div className="p-4 border-t border-slate-800">
        <button 
          onClick={onToggle}
          className="w-full flex items-center justify-center p-3 rounded-xl hover:bg-slate-800 transition-colors"
        >
          <i className={`fas ${isOpen ? 'fa-chevron-left' : 'fa-chevron-right'}`}></i>
        </button>
      </div>
    </div>
  );
};

const NavItem = ({ icon, label, active, isOpen }: any) => (
  <div className={`flex items-center gap-4 p-3 rounded-xl cursor-pointer transition-all ${active ? 'bg-blue-600 shadow-lg shadow-blue-900/20' : 'hover:bg-slate-800 text-slate-400 hover:text-white'}`}>
    <i className={`fas ${icon} w-6 text-center text-lg`}></i>
    {isOpen && <span className="font-medium">{label}</span>}
  </div>
);
